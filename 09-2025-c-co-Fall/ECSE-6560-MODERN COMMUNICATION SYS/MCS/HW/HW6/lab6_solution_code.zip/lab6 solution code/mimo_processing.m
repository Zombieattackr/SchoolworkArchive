function [syms_eq_mat_pilots_case1,syms_eq_mat_pilots_case2,syms_eq_mat_pilots_case3] = ...
    mimo_processing(rx_H_est_1A,rx_H_est_1B,rx_H_est_1C,rx_H_est_1D,...
        syms_f_mat_1A,syms_f_mat_1B,syms_f_mat_1C,syms_f_mat_1D,syms_f_mat_AA)

syms_eq_mat_pilots_1A = syms_f_mat_1A .* repmat(rx_H_est_1A',1,size(syms_f_mat_1A,2));
syms_eq_mat_pilots_1B = syms_f_mat_1B .* repmat(rx_H_est_1B',1,size(syms_f_mat_1A,2));
syms_eq_mat_pilots_1C = syms_f_mat_1C .* repmat(rx_H_est_1C',1,size(syms_f_mat_1A,2));
syms_eq_mat_pilots_1D = syms_f_mat_1D .* repmat(rx_H_est_1D',1,size(syms_f_mat_1A,2));

% Perform signal combining for MIMO 1X2, 1X4 and 2X1

% case 1 MIMO 1X2
syms_eq_mat_pilots_case1=(syms_eq_mat_pilots_1A+ syms_eq_mat_pilots_1B);

% case 2 MIMO 1X4
syms_eq_mat_pilots_case2=(syms_eq_mat_pilots_1A+ syms_eq_mat_pilots_1B+ syms_eq_mat_pilots_1C+ syms_eq_mat_pilots_1D);

% case 3 MIMO 2x1
syms_eq_mat_pilots_case3=syms_f_mat_AA;

end