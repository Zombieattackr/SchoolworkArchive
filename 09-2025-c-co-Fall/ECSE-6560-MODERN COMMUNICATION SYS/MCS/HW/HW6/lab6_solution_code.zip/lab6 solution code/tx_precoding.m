function [tx_vec_air_AA,tx_vec_air_BA] = tx_precoding(tx_vec_air_A,tx_vec_air_B,h1A,h1B)
tx_vec_air_AA = tx_vec_air_A* conj(h1A)/sqrt(abs(h1A)^2+abs(h1B)^2);
tx_vec_air_BA = tx_vec_air_B* conj(h1B)/sqrt(abs(h1A)^2+abs(h1B)^2);
end