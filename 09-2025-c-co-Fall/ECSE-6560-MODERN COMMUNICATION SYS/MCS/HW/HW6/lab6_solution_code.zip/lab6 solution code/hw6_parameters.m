SNR_list = 0:1:10; % SNR in dB
N_iter = 100; % number of Monte-Carlo iterations

USE_CHANNEL_ESTIMATES = 0;
CFO_FLAG = 0; % flag to enable CFO
DETECTION_OFFSET = 100; % to add packet detection error
LTS_CORR_THRESH = .8; % correlation threshold for LTS detection
DO_APPLY_CFO_CORRECTION = 0; % flag to enable CFO correction