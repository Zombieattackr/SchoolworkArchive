function op_struct=rx_demodulation(pidx,op_struct,params)

op_struct.rx_data(:,pidx) = qamdemod(op_struct.rx_syms(:,pidx),params.MOD_ORDER,'UnitAveragePower',true);

end