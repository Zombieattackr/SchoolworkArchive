function [lts_ind,params] = rx_pack_detect(raw_rx_dec,params)

if(~isfield(params,'max_len_to_check'))
    params.max_len_to_check = min(40000,length(raw_rx_dec));
else
    params.max_len_to_check = min(params.max_len_to_check, length(raw_rx_dec));
end

% Complex cross correlation of Rx waveform with time-domain LTS
lts_corr = abs(conv(conj(fliplr(params.lts_t)), sign(raw_rx_dec(1:params.max_len_to_check))));

% Skip early and late samples - avoids occasional false positives from pre-AGC samples
lts_corr = lts_corr(params.N_SC/2:end-params.N_SC/2);
lts_corr = lts_corr(1:min(params.max_len_to_check,length(lts_corr)));
% Find all correlation peaks
lts_peaks = find(lts_corr > params.LTS_CORR_THRESH*max(lts_corr));

% Select best candidate correlation peak as LTS-payload boundary
[LTS1, LTS2] = meshgrid(lts_peaks,lts_peaks);
[lts_second_peak_index,~] = find(LTS2-LTS1 == length(params.lts_t));

% Set a random value if no valid correlation peak was found
if(isempty(lts_second_peak_index))
    fprintf('No LTS Correlation Peaks Found!\n');
    lts_ind = -1;
    return;
end

% Set the sample indices of the payload symbols and preamble
payload_ind = lts_peaks(min(lts_second_peak_index)) + params.N_SC/2;
lts_ind = payload_ind-2.5*params.N_SC;

cur_sec_peak_ind = 2;
while(lts_ind<=0)
    payload_ind = lts_peaks(lts_second_peak_index(cur_sec_peak_ind)) + params.N_SC/2;
    lts_ind = payload_ind-2.5*params.N_SC;
    cur_sec_peak_ind = cur_sec_peak_ind+1;
end
% Rx LTS correlation
if(isfield(params,'force_lts_ind'))
    lts_ind = params.force_lts_ind;    
end
params.lts_ind = lts_ind;

if(params.plot_flag)
    figure(params.cf);clf;
    params.cf = params.cf+1;
    lts_to_plot = lts_corr(1:params.max_len_to_check);
    plot(lts_to_plot, '.-b', 'LineWidth', 1);
    hold on;
    grid on;
    line([1 length(lts_to_plot)], params.LTS_CORR_THRESH*max(lts_to_plot)*[1 1], 'LineStyle', '--', 'Color', 'r', 'LineWidth', 2);
    title('LTS Correlation and Threshold')
    xlabel('Sample Index')
    myAxis = axis();
    axis([1, params.max_len_to_check, myAxis(3), myAxis(4)]);
end
end
