%% Channel Flags and Parameters
SIM_FLAG = 1;     % flag to run simulation, 0 to run SDR
CFO_FLAG = 0;     % flag to add CFO in simulation
SFO_FLAG = 0;     % flag to add SFO in simulation
CHANNEL_FLAG = 0; % flag to apply channel in simulation

fs = 1e6; % sampling rate
fc = 2.45e9; % carrier frequency, roughly middle of ISM band
CFO = 0; % CFO in Hz
SFO = 0; % SFO in Hz
SNRdB = Inf; % awgn SNR (dB) in channel; set inf for no noise
ofdm_params.MOD_ORDER = 2; % Modulation order (2/4/16/64 = BPSK/QPSK/16-QAM/64-QAM)
ofdm_params.N_OFDM_SYMS = 50; % Number of OFDM symbols per packet

%% Decoder Flags and Parameters
ofdm_params.DO_DECODE = 1;
ofdm_params.DO_APPLY_CFO_CORRECTION = 0;
ofdm_params.DO_APPLY_SFO_CORRECTION = 0;
ofdm_params.DO_APPLY_PHASE_ERR_CORRECTION = 0;
ofdm_params.plot_flag = 1; % Plot all figures
ofdm_params.num_packets = 10; % Number of packets to decode
ofdm_params.packet_step_size = 1; % keep it 1 in hw4