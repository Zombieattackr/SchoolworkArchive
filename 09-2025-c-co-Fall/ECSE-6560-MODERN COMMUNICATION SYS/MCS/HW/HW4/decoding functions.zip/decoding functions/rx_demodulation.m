function op_struct = rx_demodulation(pidx, op_struct, params)
% Use MATLAB built-in function qamdemod
% Input signal: op_struct.rx_syms(:,pidx)
% Modulation order: params.MOD_ORDER
% We want to have UnitAveragePower

op_struct.rx_data(:,pidx) = qamdemod(op_struct.rx_syms(:,pidx), ...
                                     params.MOD_ORDER, ...
                                     'UnitAveragePower', true);
end
