function rx_H_est = rx_channel_estimation(rx_vec_cfo_corr, lts_ind, params)
% Extract LTS from received signal and compute channel estimate
% Inputs:
%   rx_vec_cfo_corr - received signal (possibly with CFO corrected)
%   lts_ind - index where LTS starts (relative to current packet)
%   params - OFDM parameters
% Output:
%   rx_H_est - channel frequency response estimate (N_SC x 1)

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% COMPLETE THIS SECTION %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Extract the two LTS sequences from the received signal
% The LTS starts at lts_ind and consists of 2.5 identical halves
lts_start = lts_ind;
lts1_start = lts_start + params.N_SC/2;  % Skip first 0.5 LTS (GI2)
lts2_start = lts1_start + params.N_SC;   % Second LTS starts after first

% Make sure we don't exceed the vector bounds
if (lts2_start + params.N_SC - 1) > length(rx_vec_cfo_corr)
    error('Not enough samples for channel estimation');
end

% Extract both LTS sequences (each of length N_SC)
rx_lts1 = rx_vec_cfo_corr(lts1_start : lts1_start + params.N_SC - 1);
rx_lts2 = rx_vec_cfo_corr(lts2_start : lts2_start + params.N_SC - 1);

% Remove cyclic prefix from each LTS (if needed) and take FFT
% The LTS in time domain already doesn't include CP for channel estimation
rx_lts1_f = fft(rx_lts1, params.N_SC);
rx_lts2_f = fft(rx_lts2, params.N_SC);

% Average the two LTS estimates for better noise immunity
rx_lts_f = (rx_lts1_f + rx_lts2_f) / 2;

% Known LTS in frequency domain (from tx)
tx_lts_f = params.lts_f;

% Calculate channel estimate (zero-forcing)
% H_est = Y / X, where Y is received, X is transmitted
rx_H_est = rx_lts_f ./ tx_lts_f;

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Optional: Plot channel estimate if flag is set
if params.plot_flag
    figure(params.cf); 
    params.cf = params.cf + 1;
    
    subplot(2,1,1);
    plot(params.SC_IND_DATA, abs(rx_H_est(params.SC_IND_DATA)), 'b.-', 'LineWidth', 2);
    hold on;
    plot(params.SC_IND_PILOTS, abs(rx_H_est(params.SC_IND_PILOTS)), 'ro', 'MarkerSize', 8, 'LineWidth', 2);
    grid on;
    title('Channel Estimate - Magnitude');
    xlabel('Subcarrier Index');
    ylabel('Magnitude');
    legend('Data Subcarriers', 'Pilot Subcarriers');
    
    subplot(2,1,2);
    plot(params.SC_IND_DATA, angle(rx_H_est(params.SC_IND_DATA)), 'b.-', 'LineWidth', 2);
    hold on;
    plot(params.SC_IND_PILOTS, angle(rx_H_est(params.SC_IND_PILOTS)), 'ro', 'MarkerSize', 8, 'LineWidth', 2);
    grid on;
    title('Channel Estimate - Phase');
    xlabel('Subcarrier Index');
    ylabel('Phase (radians)');
    legend('Data Subcarriers', 'Pilot Subcarriers');
end

end