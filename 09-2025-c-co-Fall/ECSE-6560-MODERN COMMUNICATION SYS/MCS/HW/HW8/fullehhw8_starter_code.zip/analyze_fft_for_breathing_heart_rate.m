function [Pabs, f_axis] = analyze_fft_for_breathing_heart_rate(Trep, Nchirps, phase_all)
% analyze_fft_for_breathing_heart_rate  FFT of slow-time phase for breathing/HR
% Normalized FFT so amplitudes correspond to signal amplitude (not scaled by N).

    % remove DC
    phase_detrend = phase_all - mean(phase_all);

    % compute FFT (length Nchirps)
    P = fft(phase_detrend, Nchirps);

    % Normalize by Nchirps to undo FFT amplitude scaling
    P = P ./ Nchirps;

    % magnitude (absolute). return full spectrum (user can plot subset).
    Pabs = abs(P);

    % frequency axis (Hz)
    f_axis = (0:(Nchirps-1))' ./ (Nchirps * Trep);
end
