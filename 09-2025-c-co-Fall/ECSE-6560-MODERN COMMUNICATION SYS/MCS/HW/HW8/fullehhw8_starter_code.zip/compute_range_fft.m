function [RangeFFT, range_axis] = compute_range_fft(adc_sampled, Nsample, Bchirp, c)
% compute_range_fft  Compute fast-time FFT (range FFT) and range axis
%   adc_sampled : N_chirps x Nsample matrix (slow-time rows, fast-time cols)
%   Nsample     : number of fast-time samples per chirp
%   Bchirp      : chirp bandwidth [Hz]
%   c           : speed of light [m/s]
%
%   RangeFFT    : N_chirps x Nsample complex FFT results (FFT along fast-time)
%   range_axis  : 1 x Nsample vector of range values [m] for FFT bins

    % FFT along fast-time (dimension 2). Keep full Nsample-point FFT.
    RangeFFT = fft(adc_sampled, Nsample, 2);

    % Range axis:
    % For linear FMCW, a beat-frequency bin m corresponds to range
    % R = (c/(2*Bchirp)) * m  for m = 0..Nsample-1
    % (this follows from fb = m*(1/T_chirp) and R = c*fb/(2k), k=B/T_chirp)
    m = 0:(Nsample-1);
    range_axis = (c ./ (2 * Bchirp)) .* m;
end
