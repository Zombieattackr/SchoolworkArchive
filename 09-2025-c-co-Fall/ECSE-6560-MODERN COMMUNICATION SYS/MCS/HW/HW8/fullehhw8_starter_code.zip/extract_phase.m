function phase_all = extract_phase(RangeFFT, rangeBin, Trep)
% extract_phase  Extract and unwrap phase across slow time at a given range bin
%   RangeFFT  : N_chirps x Nsample matrix (complex)
%   rangeBin  : index of range bin to extract (scalar)
%   Trep      : chirp repetition interval (not used in computation here but kept in signature)
%
%   phase_all : N_chirps x 1 vector of unwrapped phase (radians)
%
% Note: Trep is present because the assignment specified it in the signature.
%       It is not required to perform unwrap; kept for compatibility.

    % extract complex slow-time samples at the chosen range bin
    % RangeFFT is N_chirps x Nsample, columns correspond to range bins
    slow_time_complex = RangeFFT(:, rangeBin);

    % instantaneous phase and unwrap across slow time
    phase_all = unwrap(angle(slow_time_complex));
end
