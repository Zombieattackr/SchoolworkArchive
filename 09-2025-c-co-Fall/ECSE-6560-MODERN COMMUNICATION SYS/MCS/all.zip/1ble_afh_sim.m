% Simulation of BLE with AFH, GFSK mod/demod, and interference. 
% Measures packet loss, throughput, p95 latency.
%
% Paste into a file and run in MATLAB.

clear; close all; rng(0);

%% ---------------- Simulation Parameters ----------------
sim.totalPackets = 2000;     % number of packets to attempt to send
sim.payloadBytes = 20;       % bytes per logical payload (application data)
sim.maxRetransmit = 4;       % max retransmissions (retries)
sim.connInterval_ms = 7.5;   % connection interval (ms) - time between connection events
sim.phy_rate = 1e6;          % physical layer bit rate (bps) - 1 Mbps BLE legacy
sim.slot_time_ms = 1;        % use this as minimal scheduler granularity (ms)
sim.sampleRate = 1e6;        % sampling rate for GFSK baseband (samples/sec)
sim.bt_gaussianBT = 0.5;     % BT product for Gaussian filter in GFSK
sim.modIndex = 0.5;          % GFSK modulation index
sim.preambleBits = 8*1;      % preamble 8*bytes=bits
sim.accessAddrBits = 32;     % access address bits
sim.crcBits = 24;            % CRC bits
sim.psdu_len_bytes = sim.payloadBytes;

%% Noise & Interference Parameters (tune these)
chan.noise_dBm = -90;        % background noise floor per channel (dBm)
chan.signal_power_dBm = -35; % transmitted signal power at receiver (dBm)
chan.interference_power_dBm = -40; % peak interferer power (dBm) for spikes
chan.awgn_enable = true;     % enable AWGN
chan.interference_enable = true;

% Interference schedule: list of interferers. 
% Each has center frequency (BLE channel index), bandwidth in number of BLE channels, mean amplitude (dBm), and a time-varying process.
% Real-world style interferers: Wi-Fi APs + many Bluetooth devices / audio streams
% Note: BLE data channels are indexed 0..36; Wi-Fi 2.4 GHz channel centers are mapped to approximate BLE channel indices:
%  Wi-Fi ch1 (2412 MHz) -> ~BLE ch5; ch6 (2437 MHz) -> ~BLE ch18; ch11 (2462 MHz) -> ~BLE ch30.
interferers = struct(...
    'centerCh',         { 5,    18,   30,   12,   7,    25,   2,    32,   20,   14,   9,    28,   16,   4,    22,   11,   33,   0,    35,   19   }, ...
    'bwCh',             { 8,    8,    8,    3,    2,    4,    1,    3,    2,    2,    1,    3,    2,    1,    3,    1,    2,    1,    1,    2    }, ...
    'mean_dBm',         {-35,  -38,  -36,  -50,  -60,  -45,  -70,  -48,  -42,  -55,  -65,  -50,  -58,  -68,  -46,  -62,  -40,  -75,  -50,  -53   }, ...
    'onProb',           { 0.95, 0.9,  0.9,  0.25, 0.12, 0.35, 0.05, 0.2,  0.4,  0.18, 0.07, 0.22, 0.15, 0.06, 0.3,  0.1,  0.6,  0.02, 0.08, 0.25 }, ... 
    'duration_mean_ms', { 2000, 1500, 1800, 80,   40,   300,  15,   120,  200,  60,   20,   100,  50,   10,   250,  30,   400,  8,    70,   90   } ...
    );
% Explanation of a few entries (for clarity):
%   - entries 1-3: Wi-Fi APs (very wide 'bwCh' to cover many BLE channels, high mean power, very likely to be on)
%   - entries 4-6: Bluetooth audio streaming devices (moderate-high power, moderate on-probability, multi-channel spread)
%   - entries 7,11,18: low-power/rare devices (e.g., keyboard/mouse, small sensors)
%   - others: mix of phones, TVs, other BLE peripherals with varied duty cycles/durations

%% BLE channel / AFH parameters
ble.Ndata = 37;   % number of data channels (BLE data channels 0..36)
ble.hopIncrement = 5;  % hop increment [1..16 typical], affects sequence
ble.channel_map = true(1, ble.Ndata);  % boolean, true = allowed
ble.chan_quality_window = 50; % number of packet samples to evaluate channel quality
ble.bad_rate_threshold = 0.4; % if failure rate > threshold mark bad
ble.min_channels_for_use = 5; % AFH must leave at least this many channels
ble.recovery_time_ms = 2000;  % after which a bad channel is eligible for retest

%% PHY / timing derived params
bitsPerPacket = sim.preambleBits + sim.accessAddrBits + 8*sim.psdu_len_bytes + sim.crcBits;
packetTxTime_s = bitsPerPacket / sim.phy_rate;
packetTxTime_ms = packetTxTime_s*1e3;

%% Convert dBm to linear power (arbitrary units)
dbm2mW = @(d) 10.^((d-30)/10); % convert dBm to mW
signal_power_mW = dbm2mW(chan.signal_power_dBm);
noise_floor_mW = dbm2mW(chan.noise_dBm);
interf_peak_mW = dbm2mW(chan.interference_power_dBm);

%% Initialize AFH stats
chan.attempts = zeros(1, ble.Ndata);
chan.failures = zeros(1, ble.Ndata);
chan.lastBadTime_ms = -inf(1, ble.Ndata);
chan.isBad = ~ble.channel_map; % start with map (all good here)

% random seed for interferer scheduling
t_ms = 0; % simulation clock (ms)
simTotalTime_ms = 0;
nextInterfererEnd_ms = zeros(1, numel(interferers));
interfererActive = false(1,numel(interferers));

% Results collection
results.packetSent = 0;
results.packetSuccess = 0;
results.latencies_ms = [];
results.retransmissions = zeros(sim.totalPackets,1);
results.totalRetransmissions = 0;

%% Helper: channel list function that returns current good channel vector
function goodList = getGoodChannels(chan, ble)
    goodList = find(~chan.isBad);
    % ensure minimum number of channels remain usable
    if numel(goodList) < ble.min_channels_for_use
        failureRate = chan.failures ./ max(1, chan.attempts);
        [~, idx] = sort(failureRate, 'ascend');
        allowed = idx(1:ble.min_channels_for_use);
        goodList = allowed;
    end
end


% Hopping sequence selection using a remapping on the list of allowed channels
% This approximates BLE Data Channel Selection #1 by remapping to the reduced map.
function ch = selectChannel(counter, chan, ble)
    goodList = getGoodChannels(chan, ble);
    N = numel(goodList);

    % BLE-like hop mapping
    idx = mod(counter * ble.hopIncrement, N) + 1;   
    ch = goodList(idx);
end


%% --- GFSK modulator / demodulator functions (baseband) -----------
% We implement simple binary GFSK at baseband: NRZ +/-1 shaped by gaussian
% filter -> instantaneous frequency -> complex exponential generation.
function s = gfsk_mod(bits, fs, bt, h, samplesPerBit)
    % bits: 0/1 vector
    % fs: sample rate
    % bt: gaussian BT product
    % h: modulation index
    % samplesPerBit: number of samples per symbol
    % returns complex baseband signal
    % map bits 0->-1, 1->+1
    b = double(bits(:));
    nrz = 2*b - 1;
    % Gaussian filter design
    span = 4; % symbol spans
    t = (-span/2 : 1/samplesPerBit : span/2);
    alpha = sqrt(log(2))/ (2*pi*bt);
    g = exp(- ( (t/alpha).^2 )/2);
    g = g / sum(g);
    shaped = conv(nrz, g, 'same');
    % instantaneous phase integration
    freq_dev = (h/2) * shaped; % scaled freq deviation per symbol
    % integrate freq to phase
    phase = 2*pi * cumsum(freq_dev) / samplesPerBit;
    s = exp(1j*phase).';
end

function bitsHat = gfsk_demod(rx, samplesPerBit)
    % simple frequency discriminator using phase difference
    % compute instantaneous frequency (phase derivative)
    phi = unwrap(angle(rx));
    instFreq = diff(phi); % phase difference per sample
    % downsample by samplesPerBit: integrate per symbol
    L = floor(length(instFreq)/samplesPerBit);
    symVals = zeros(1, L);
    for k=1:L
        symVals(k) = mean(instFreq((k-1)*samplesPerBit+1 : k*samplesPerBit));
    end
    % decide: positive -> 1, negative -> 0
    bitsHat = symVals > 0;
end

%% Precompute waveform lengths to keep simulation time reasonable
samplesPerBit = round(sim.sampleRate / sim.phy_rate);
if samplesPerBit < 2, samplesPerBit = 2; end

%% Interference process helper
function currentInterfPower = getInterferencePowerForChannel(chIdx, time_ms, interferers, interfererActive, nextInterfererEnd_ms)
    % recompute dBm->mW converter locally (safe for function scope)
    dbm2mW_local = @(d) 10.^((d-30)/10);

    currentInterfPower = 0;
    for ii = 1:numel(interferers)
        % only contribute if the interferer is active AND its scheduled end time > now
        if interfererActive(ii) && time_ms < nextInterfererEnd_ms(ii)
            center = interferers(ii).centerCh;
            bw = interferers(ii).bwCh;
            % triangular roll-off in channel domain
            dist = abs(chIdx - center);
            if dist <= bw/2
                weight = 1 - dist/(bw/2);
                p = dbm2mW_local(interferers(ii).mean_dBm) * weight;
                currentInterfPower = currentInterfPower + p;
            end
        end
    end
end


%% Main loop: send packets, AFH, channel selection, mod/demod, ack/retransmit
hopCounter = 0; % incremented each packet tx attempt
simClock_ms = 0;

for pktIdx = 1:sim.totalPackets
    % application payload bits
    appBits = randi([0 1], 1, 8*sim.psdu_len_bytes);
    attempts = 0;
    success = false;
    startTime_ms = simClock_ms;
    while ~success && attempts <= sim.maxRetransmit
        attempts = attempts + 1;
        hopCounter = hopCounter + 1;
        % select channel using AFH-remap method
        ch = selectChannel(hopCounter, chan, ble);
        % update attempt count
        chan.attempts(ch) = chan.attempts(ch) + 1;
        % create packet bits (preamble+access+payload+crc) - simplified
        pktBits = [randi([0 1],1, sim.preambleBits), randi([0 1],1, sim.accessAddrBits), appBits, randi([0 1],1, sim.crcBits)];
        % GFSK modulate
        txSig = gfsk_mod(pktBits, sim.sampleRate, sim.bt_gaussianBT, sim.modIndex, samplesPerBit);
        % Channel: compute noise + interference on that channel at this time
        % For speed, we don't frequency shift the waveform; instead we treat the waveform
        % as occupying the channel center; interference/noise affect SNR.
        % compute interfering power
        % update interferer activations randomly over time
        for ii = 1:numel(interferers)
            if ~interfererActive(ii)
                if rand < interferers(ii).onProb
                    interfererActive(ii) = true;
                    dur = max(1, round(interferers(ii).duration_mean_ms * (0.5 + rand)));
                    nextInterfererEnd_ms(ii) = simClock_ms + dur;
                end
            else
                if simClock_ms >= nextInterfererEnd_ms(ii)
                    interfererActive(ii) = false;
                end
            end
        end
        % interference power for this channel (mW)
        interfPower_mW = getInterferencePowerForChannel(ch, simClock_ms, interferers, interfererActive, nextInterfererEnd_ms);
        % AWGN noise power (per band) use noise_floor_mW
        noise_mW = noise_floor_mW;
        if ~chan.awgn_enable
            noise_mW = 0;
        end
        totalNoisePlusInterf_mW = noise_mW + interfPower_mW;
        % compute linear SNR based on signal_power_mW and noise+interf
        SNR_linear = signal_power_mW / max(1e-12, totalNoisePlusInterf_mW);
        % Map SNR to BER for GFSK approximate formula (use coherent FSK approx)
        % Eb/N0 = SNR * (BW/Rb) but here we take ratio approximated
        EbN0 = SNR_linear * (sim.sampleRate / sim.phy_rate); % rough scaling
        % approximate BER for binary FSK coherent: erfc(sqrt(EbN0/2))/2
        ber = 0.5 * erfc( sqrt(EbN0/2) );
        % protect limits
        ber = min(max(ber, 1e-12), 0.5);
        % compute packet error probability
        pktLenBits = length(pktBits);
        pErr = 1 - (1 - ber) ^ pktLenBits;
        % decide packet success
        if rand > pErr
            % successful reception
            success = true;
            results.packetSuccess = results.packetSuccess + 1;
            % reset channel failure counters on success?
            % optionally decay counters; here we'll count success implicitly
        else
            % failure
            chan.failures(ch) = chan.failures(ch) + 1;
            % record last failure time for recovery logic
            chan.lastBadTime_ms(ch) = simClock_ms;
        end
        % Simulate time progression: packet tx time + ack round trip (if success) or next conn event
        % For simplicity: if success, ack takes a single slot (assume immediate with some small delay)
        if success
            % assume ack and small turnaround: 1 * slot_time_ms + packetTxTime_ms
            simClock_ms = simClock_ms + packetTxTime_ms + 0.5; % ack latency approx
        else
            % no ack -> wait until next connection event (connInterval)
            simClock_ms = simClock_ms + sim.connInterval_ms;
        end
        % Optionally update AFH: evaluate channels every chan.chan_quality_window attempts
        if mod(sum(chan.attempts), ble.chan_quality_window) == 0
            % compute failure rates and mark channels bad/good
            frate = chan.failures ./ max(1, chan.attempts);
            for cidx = 1:ble.Ndata
                if frate(cidx) > ble.bad_rate_threshold && ~chan.isBad(cidx)
                    chan.isBad(cidx) = true;
                    chan.lastBadTime_ms(cidx) = simClock_ms;
                    fprintf('Mark channel %d BAD at t=%.1f ms (fail rate %.2f)\n', cidx-1, simClock_ms, frate(cidx));
                end
                % allow recovery if enough time passed
                if chan.isBad(cidx)
                    if (simClock_ms - chan.lastBadTime_ms(cidx)) > ble.recovery_time_ms
                        % retest by allowing the channel back into map but with reset counts
                        chan.isBad(cidx) = false;
                        chan.attempts(cidx) = 0;
                        chan.failures(cidx) = 0;
                        fprintf('Recovering channel %d at t=%.1f ms\n', cidx-1, simClock_ms);
                    end
                end
            end
        end
    end % attempts loop

    % record results for the packet
    results.packetSent = results.packetSent + 1;
    results.retransmissions(pktIdx) = attempts - 1;
    results.totalRetransmissions = results.totalRetransmissions + (attempts - 1);
    if success
        latency_ms = simClock_ms - startTime_ms;
        results.latencies_ms(end+1) = latency_ms;
    else
        % even after max retransmit, consider it lost and advance time minimally
        simClock_ms = simClock_ms + sim.connInterval_ms;
    end

    % periodic display
    if mod(pktIdx, 200) == 0
        fprintf('Sent %d/%d packets. Success %d. Time %.1f s\n', pktIdx, sim.totalPackets, results.packetSuccess, simClock_ms/1000);
    end
end

simTotalTime_ms = simClock_ms;

%% Compute metrics and print
totalSent = results.packetSent;
totalSuccess = results.packetSuccess;
packetLossRate = 1 - totalSuccess/totalSent;
totalPayloadBits = totalSuccess * sim.payloadBytes * 8;
throughput_bps = totalPayloadBits / (simTotalTime_ms/1000);
p95_latency = prctile(results.latencies_ms, 95);
p99_latency = prctile(results.latencies_ms, 99);
max_latency = max(results.latencies_ms);
avg_retrans_success = NaN;
if totalSuccess>0
    avg_retrans_success = mean(results.retransmissions(1:totalSuccess));
end

fprintf('\n--- Simulation Summary ---\n');
fprintf('Packets sent: %d, Successful: %d, Lost: %d (loss=%.3f)\n', totalSent, totalSuccess, totalSent-totalSuccess, packetLossRate);
fprintf('Throughput (application bits/s): %.1f bps, %.1 KBps\n', throughput_bps, throughput_bps/8/1024);
fprintf('Median latency (ms): %.2f, p95 latency (ms): %.2f, p99 latency (ms): %.2f, max latency (ms): %.2f\n', median(results.latencies_ms), p95_latency, p99_latency, max_latency);
fprintf('Average retransmissions per packet (successful only): %.4f\n', mean(results.retransmissions(1:totalSuccess)));
fprintf('Total retransmissions (all packets): %d\n', results.totalRetransmissions);

%% Plot some diagnostics
figure('Name','AFH Channel Stats','NumberTitle','off');
subplot(2,1,1);
bar(0:ble.Ndata-1, chan.attempts); ylabel('Attempts'); xlabel('Data channel index');
title('Channel Attempts');
subplot(2,1,2);
bar(0:ble.Ndata-1, chan.failures); ylabel('Failures'); xlabel('Data channel index');
title('Channel Failures');

figure('Name','Latency CDF','NumberTitle','off');
histogram(results.latencies_ms, 100, 'Normalization','cdf');
xlabel('Latency (ms)'); ylabel('CDF'); grid on;
title('Latency CDF');

figure('Name','Retransmissions','NumberTitle','off');
histogram(results.retransmissions(1:totalSent), 0:sim.maxRetransmit);
xlabel('Retransmissions'); ylabel('Count'); grid on;
title('Retransmissions per Packet');

%% End of simulation
