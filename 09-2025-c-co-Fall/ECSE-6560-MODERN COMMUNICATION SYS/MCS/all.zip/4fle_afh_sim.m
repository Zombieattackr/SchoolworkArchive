function ble_afh_sim()
% ble_afh_sim() - BLE AFH simulator with diagnostics:
%  - channels vs time heatmap (good vs bad) with success/fail markers
%  - retransmissions histogram with integer-centered bins and log y-scale
%  - selectable AFH algorithm: 1 (remap over allowed list), 2 (approx BLE DCS #2 approx), 3 (custom)
%
% Paste as ble_afh_sim.m and run ble_afh_sim()

%% ---------------- Simulation Parameters ----------------
rng(0); clearvars -except rng; close all;

selAlg = 1;
classAlg = 0;

sim.totalPackets = 20000;     % number of packets to attempt to send
sim.payloadBytes = 20;       % bytes per logical payload (application data)
sim.maxRetransmit = 4;       % max retransmissions (retries)
sim.connInterval_ms = 7.5;   % connection interval (ms)
sim.phy_rate = 1e6;          % physical layer bit rate (bps)
sim.sampleRate = 1e6;        % sampling rate for GFSK baseband
sim.bt_gaussianBT = 0.5;
sim.modIndex = 0.5;
sim.preambleBits = 8*1;
sim.accessAddrBits = 32;
sim.crcBits = 24;
sim.psdu_len_bytes = sim.payloadBytes;

%% Noise & Interference Parameters (tune these)
chan.noise_dBm = -90;
chan.signal_power_dBm = -50;
chan.interference_power_dBm = -40;
chan.awgn_enable = true;
chan.interference_enable = true;
% Global offsets (already suggested) - these are used only at initialization to
% build per-interferer per-mode means (the runtime helper reads the baked values).
interferenceOffset = 0;                % global offset applied to all interferers (dB)
periodicInterferenceOffset_dB = 0;     % offset for periodic pulses
randomInterferenceOffset_dB = 0;       % offset for random bursts (gate ON)
mixedInterferenceOffset_dB = 0;        % offset when mixed (periodic pulse during gate ON)

% Random-gate distribution controls (for mixed-mode long ON/OFF lifetimes)
% We'll draw ON durations from Dur = max(1, round(duration_mean_ms * (0.5 + rand)))
% If you'd prefer exponential, I can change to exprnd(duration_mean_ms).
% Also per-loop start probability scale for random gates (tunable)
randomGatePerLoopStartScale = 1e-3;    % scale factor for onProb -> per-loop chance



%% Real-world style interferers (example) - feel free to replace
% Fields:
%  centerCh (0-based channel index), bwCh (channel bandwidth in BLE channels),
%  mean_dBm, onProb (used for random-mode interferers), duration_mean_ms (for random bursts)
%  isPeriodic (true/false) : whether interferer sends periodic pulses/beacons
%  period_ms (period for periodic beacons)
%  jitter_ms (random jitter added to each period, +/- this amount)
%  onDuration_ms (how long each periodic pulse lasts)
%  startRandom (true/false) : if true, periodic activity starts at a random offset
%  mode: 'periodic', 'random', 'mixed'  - periodic only, random-only, or both behaviors
interferers = struct(...
    'centerCh', { 5,   18,  30,  12,  7,   25,  2,   32,  20,  14,  9,   28,  16,  4,   22,  11,  33,  0,  35,  19 }, ...
    'bwCh',     { 20,  20, 20,  3,   2,   4,   1,   3,   2,   2,   1,   3,   2,   1,   3,   1,   2,   1,   1,   2 }, ...
    'mean_dBm', {  5,   2,   4,  -10, -20,  3,  -30, -12,  1,  -15, -25, -10, -18, -28,   2, -22,   6, -40, -12, -14 }, ...
    'onProb',   { 0.95, 0.9, 0.9, 0.25, 0.12, 0.35, 0.05, 0.2,  0.4,  0.18, 0.07, 0.22, 0.15, 0.06, 0.3,  0.1,  0.6,  0.02, 0.08, 0.25 }, ... 
    'duration_mean_ms', { 2000, 1500, 1800, 80,  40,  300,  15,  120,  200,  60,   20,   100,  50,   10,   250,  30,   400,  8,   70,   90 }, ...
    'isPeriodic', { true, true, true, false, false, true, false, false, true, false, false, false, false, false, true, false, true, false, false, true }, ...
    'period_ms', { 100, 100, 100, 0, 0, 100, 0, 0, 100, 0, 0, 0, 0, 0, 100, 0, 100, 0, 0, 100 }, ...
    'jitter_ms', { 5, 10, 8, 0, 0, 20, 0, 0, 15, 0, 0, 0, 0, 0, 12, 0, 7, 0, 0, 10 }, ...
    'onDuration_ms', { 5, 5, 5, 80, 40, 10, 15, 120, 6, 60, 20, 100, 50, 10, 8, 30, 5, 8, 70, 6 }, ...
    'startRandom', { true, true, true, false, false, true, false, false, true, false, false, false, false, false, true, false, true, false, false, true }, ...
    'mode', {'mixed','mixed','mixed','random','random','mixed','random','random','mixed','random','random','random','random','random','mixed','random','mixed','random','random','mixed'} ...
    );

% Apply global and per-mode offsets into the interferers struct so helper functions
% don't need to reference external offset variables.
for k = 1:numel(interferers)
    % base mean after applying the global offset AND the channel-wide interference power
    % so chan.interference_power_dBm affects everything.
    interferers(k).mean_base_dBm = interferers(k).mean_dBm + interferenceOffset;

    % per-reason effective means (apply additional offsets)
    interferers(k).mean_periodic_dBm = interferers(k).mean_base_dBm + periodicInterferenceOffset_dB;
    interferers(k).mean_random_dBm   = interferers(k).mean_base_dBm + randomInterferenceOffset_dB;
    interferers(k).mean_mixed_dBm    = interferers(k).mean_base_dBm + mixedInterferenceOffset_dB;

    % default effective mean (will be updated on activation)
    interferers(k).mean_effective_dBm = interferers(k).mean_base_dBm;

    % small debug field (optional)
    interferers(k).dbg_lastReason = "";
end





%% BLE channel / AFH parameters
ble.Ndata = 37;   % data channels 0..36
ble.hopIncrement = 67;
ble.channel_map = true(1, ble.Ndata);
ble.chan_quality_window = 50;
ble.bad_rate_threshold = 0.4;
ble.min_channels_for_use = 20;
ble.recovery_time_ms = 2000;
% choose AFH selection algorithm: 1, 2, ~~or 3~~
ble.afh_selection_algorithm = selAlg;
% choose AFH classification algorithm: 0-5 : none, 
ble.afh_classification_algorithm = classAlg;
% only used for algorithm 2
ble.accessAddress = 0x8E89BED6;
ble.channelIdentifier = 0;
ble.eventCounter = 0;

%% Derived
bitsPerPacket = sim.preambleBits + sim.accessAddrBits + 8*sim.psdu_len_bytes + sim.crcBits;
packetTxTime_ms = (bitsPerPacket / sim.phy_rate) * 1e3;
dbm2mW = @(d) 10.^((d-30)/10);
signal_power_mW = dbm2mW(chan.signal_power_dBm);
noise_floor_mW = dbm2mW(chan.noise_dBm);

%% Initialize channel stats and interferer scheduling
chan.attempts = zeros(1, ble.Ndata);
chan.failures = zeros(1, ble.Ndata);
chan.lastBadTime_ms = -inf(1, ble.Ndata);
chan.isBad = ~ble.channel_map;
interfererActive = false(1,numel(interferers));
nextInterfererEnd_ms = zeros(1,numel(interferers));
% Scheduling helper arrays for periodic interferers (existing from before)
nextInterfererEvent_ms = inf(1, numel(interferers));
periodicStarted = false(1, numel(interferers));
% Track reason for activation: "periodic", "random", "mixed", or ""
interfererActiveReason = strings(1, numel(interferers));

% For multiplicative mixed mode: random gating state & end times (long ON/OFF)
randomGateActive = false(1, numel(interferers));      % gate ON/OFF state
randomGateEnd_ms = zeros(1, numel(interferers));      % when the gate will turn OFF (if ON)
randomGateNextStart_ms = zeros(1, numel(interferers));% optional next start scheduling (not required)
% initialize next periodic events as before
for ii = 1:numel(interferers)
    if interferers(ii).isPeriodic
        if interferers(ii).startRandom
            nextInterfererEvent_ms(ii) = round(rand * interferers(ii).period_ms);
        else
            nextInterfererEvent_ms(ii) = 0;
        end
    else
        nextInterfererEvent_ms(ii) = Inf;
    end
    interfererActiveReason(ii) = "";
end

% per-channel energy history (dBm) for energy-based classifiers
if ~isfield(chan,'energy_history') || isempty(chan.energy_history)
    chan.energy_history = cell(1, ble.Ndata);
end
% counters used by the energy classifier
if ~isfield(chan,'energy_bad_count'), chan.energy_bad_count = zeros(1, ble.Ndata); end


%% Results
results.packetSent = 0;
results.packetSuccess = 0;
results.latencies_ms = [];
results.retransmissions = zeros(sim.totalPackets,1);
results.totalRetransmissions = 0;

%% Timeline / diagnostics storage
% upper bound on events = totalPackets * (maxRetransmit+1)
maxEvents = sim.totalPackets * (sim.maxRetransmit + 1);
chanStateTimeline = false(ble.Ndata, maxEvents); % per-event snapshot of channel good(1)/bad(0)
eventChannel = zeros(1, maxEvents);   % channel used at each event
eventSuccess = false(1, maxEvents);   % whether the event succeeded
eventTime_ms = zeros(1, maxEvents);   % timestamp when event occurred
eventIdx = 0;

%% Modulation parameters
samplesPerBit = max(2, round(sim.sampleRate / sim.phy_rate));

%% Main loop
hopCounter = 0;
simClock_ms = 0;
lastUsedChannel = 1; % start anywhere (1..N)
for pktIdx = 1:sim.totalPackets
    appBits = randi([0 1], 1, 8*sim.psdu_len_bytes);
    attempts = 0;
    success = false;
    startTime_ms = simClock_ms;
    while ~success && attempts <= sim.maxRetransmit
        attempts = attempts + 1;
        hopCounter = hopCounter + 1;
                % ------------------ Interferer scheduling (periodic + random + multiplicative mixed) ------------------
        for ii = 1:numel(interferers)
            I = interferers(ii);

            % --- RANDOM GATE for mixed-mode and for random-mode bursts ---
            % For 'mixed' mode we treat randomGateActive as a long ON/OFF gate.
            if strcmp(I.mode,'mixed') || strcmp(I.mode,'random')
                % if gate is currently OFF and we want a new random long ON period:
                if ~randomGateActive(ii)
                    % per-loop starting probability scaled from I.onProb
                    pStart = I.onProb * randomGatePerLoopStartScale;
                    if rand < pStart
                        randomGateActive(ii) = true;
                        % choose a long gate duration (so multiple periodic pulses can occur)
                        dur = max(1, round(I.duration_mean_ms * (0.5 + rand))); % long-ish ON time
                        randomGateEnd_ms(ii) = simClock_ms + dur;
                        % mark the interferer as 'random' active only if mode is 'random' (non-mixed)
                        if strcmp(I.mode,'random')
                            interfererActive(ii) = true;
                            nextInterfererEnd_ms(ii) = simClock_ms + dur;
                            interfererActiveReason(ii) = "random";
                            % set effective mean for this active random burst
                            interferers(ii).mean_effective_dBm = interferers(ii).mean_random_dBm;
                        end
                    end
                else
                    % gate is ON; turn it off when its duration ends
                    if simClock_ms >= randomGateEnd_ms(ii)
                        randomGateActive(ii) = false;
                        randomGateEnd_ms(ii) = 0;
                        % if we had set an active random burst (mode 'random'), ensure it's cleared
                        if strcmp(I.mode,'random') && interfererActive(ii)
                            interfererActive(ii) = false;
                            nextInterfererEnd_ms(ii) = 0;
                            interfererActiveReason(ii) = "";
                            % reset effective mean to base
                            interferers(ii).mean_effective_dBm = interferers(ii).mean_base_dBm;
                        end
                    end
                end
            end

            % --- PERIODIC behavior (short pulses) ---
            if I.isPeriodic
                % Only schedule/emit a periodic pulse when its next event time arrives.
                % For 'mixed' mode these pulses will only be turned on if the randomGate is currently ON.
                if ~interfererActive(ii) && simClock_ms >= nextInterfererEvent_ms(ii)
                    % If mode == 'mixed', only start the periodic pulse when the random gate is ON
                    if strcmp(I.mode,'mixed')
                        if randomGateActive(ii)
                            % start a periodic pulse while gate ON -> this is a MIXED activation
                            interfererActive(ii) = true;
                            dur = max(1, round(I.onDuration_ms * (0.9 + 0.2*rand))); % short per-pulse length
                            nextInterfererEnd_ms(ii) = simClock_ms + dur;
                            interfererActiveReason(ii) = "mixed";
                            % set effective mean for mixed activation
                            interferers(ii).mean_effective_dBm = interferers(ii).mean_mixed_dBm;
                        else
                            % gate OFF -> skip this periodic pulse, but schedule next event anyway
                            % no activation now
                        end
                    else
                        % non-mixed periodic (pure periodic or mixed with gate irrelevant): start pulse
                        interfererActive(ii) = true;
                        dur = max(1, round(I.onDuration_ms * (0.9 + 0.2*rand)));
                        nextInterfererEnd_ms(ii) = simClock_ms + dur;
                        interfererActiveReason(ii) = "periodic";
                        % set effective mean for periodic activation
                        interferers(ii).mean_effective_dBm = interferers(ii).mean_periodic_dBm;
                    end

                    % schedule next periodic event (period + jitter)
                    base = I.period_ms;
                    jitter = 0;
                    if isfield(I,'jitter_ms') && I.jitter_ms > 0
                        jitter = (rand*2-1) * I.jitter_ms; % +/- jitter
                    end
                    nextInterfererEvent_ms(ii) = simClock_ms + max(1, round(base + jitter));
                end

                % If currently in a periodic pulse, end it when its duration expires
                if interfererActive(ii) && simClock_ms >= nextInterfererEnd_ms(ii)
                    % This could have been a 'periodic' or 'mixed' activation
                    % Clear the active flag, but keep gate state for mixed-mode
                    interfererActive(ii) = false;
                    interfererActiveReason(ii) = "";
                    % reset effective mean to base
                    interferers(ii).mean_effective_dBm = interferers(ii).mean_base_dBm;
                    nextInterfererEnd_ms(ii) = 0;
                end
            end

            % --- RANDOM burst behavior for pure-random mode (already handled partly via randomGateActive)
            % For pure 'random' mode we already set interfererActive when the random gate started (above).
            % For 'mixed' mode we DO NOT create independent random bursts; only the periodic pulses during gate ON.
            % If you want mixed to sometimes also have long random bursts in addition to gated periodic pulses,
            % we can add that later (but currently mixed = gate * periodic).
        end


        % select channel according to chosen AFH method
        ble.eventCounter = ble.eventCounter +1;
        ch = select_channel_AFH(hopCounter, lastUsedChannel, ble, chan);
        lastUsedChannel = ch;

        % update attempt counter
        chan.attempts(ch) = chan.attempts(ch) + 1;

        % generate packet bits and (optionally) modulate - here we compute SNR-based BER directly
        pktBits = [randi([0 1],1, sim.preambleBits), randi([0 1],1, sim.accessAddrBits), appBits, randi([0 1],1, sim.crcBits)];

        % compute interference power for selected channel
        interfPower_mW = getInterferencePowerForChannel(ch, simClock_ms, interferers, interfererActive, nextInterfererEnd_ms, interfererActiveReason);


        noise_mW = noise_floor_mW;
        totalNoisePlusInterf_mW = noise_mW + interfPower_mW;
        totalNoisePlusInterf_dBm = 10*log10(max(totalNoisePlusInterf_mW,1e-16)) + 30; % mW->dBm
        % push sample into channel energy history (keep bounded length)
        if ~iscell(chan.energy_history), chan.energy_history = cell(1, ble.Ndata); end
        max_energy_history = 50; % keep recent samples only (tunable)
        h = chan.energy_history{ch};
        h(end+1) = totalNoisePlusInterf_dBm;
        if numel(h) > max_energy_history, h = h(end-max_energy_history+1:end); end
        chan.energy_history{ch} = h;

        SNR_linear = signal_power_mW / max(1e-12, totalNoisePlusInterf_mW);
        EbN0 = SNR_linear * (sim.sampleRate / sim.phy_rate);
        ber = 0.5 * erfc( sqrt(EbN0/2) );
        ber = min(max(ber, 1e-12), 0.5);
        pktLenBits = length(pktBits);
        pErr = 1 - (1 - ber) ^ pktLenBits;

        % log event in timeline arrays
        eventIdx = eventIdx + 1;
        chanStateTimeline(:, eventIdx) = ~chan.isBad(:);  % snapshot of allowed channels at this event
        eventChannel(eventIdx) = ch;
        eventTime_ms(eventIdx) = simClock_ms;

        if rand > pErr
            success = true;
            eventSuccess(eventIdx) = true;
            results.packetSuccess = results.packetSuccess + 1;
            % minimal ack delay
            simClock_ms = simClock_ms + packetTxTime_ms + 0.5;
        else
            success = false;
            eventSuccess(eventIdx) = false;
            chan.failures(ch) = chan.failures(ch) + 1;
            chan.lastBadTime_ms(ch) = simClock_ms;
            simClock_ms = simClock_ms + sim.connInterval_ms;
        end

        % AFH: periodic evaluation based on attempts window (simple periodic check)


        % Dispatcher for AFH selection algorithms with explicit variable passing
        switch ble.afh_classification_algorithm
            case 0

            case 1 % fixed window failure rate
                if mod(sum(chan.attempts), ble.chan_quality_window) == 0
                    frate = chan.failures ./ max(1, chan.attempts);
                    for cidx = 1:ble.Ndata
                        if frate(cidx) > ble.bad_rate_threshold && ~chan.isBad(cidx)
                            chan.isBad(cidx) = true;
                            chan.lastBadTime_ms(cidx) = simClock_ms;
                            fprintf('Mark channel %d BAD at t=%.1f ms (fail rate %.2f)\n', cidx-1, simClock_ms, frate(cidx));
                        end
                        if chan.isBad(cidx)
                            if (simClock_ms - chan.lastBadTime_ms(cidx)) > ble.recovery_time_ms
                                chan.isBad(cidx) = false;
                                chan.attempts(cidx) = 0;
                                chan.failures(cidx) = 0;
                                fprintf('Recovering channel %d at t=%.1f ms\n', cidx-1, simClock_ms);
                            end
                        end
                    end
                    % --- ENFORCE MINIMUM CHANNELS ---
                    % Count good channels
                    goodMask = ~chan.isBad;
                    numGood = sum(goodMask);
                    if numGood < ble.min_channels_for_use
                        deficit = ble.min_channels_for_use - numGood;

                        % Sort channels by failure rate (ascending)
                        [~, idx] = sort(frate, 'ascend');

                        % Re-enable the best channels until requirement is met
                        ii = 1;
                        reEnabled = 0;
                        while reEnabled < deficit && ii <= ble.Ndata
                            c = idx(ii);
                            if chan.isBad(c)
                                chan.isBad(c) = false;
                                fprintf('Forcing channel %d GOOD to meet min_channels at t=%.1f ms\n', ...
                                        c-1, simClock_ms);
                                reEnabled = reEnabled + 1;
                            end
                            ii = ii + 1;
                        end
                    end
                end
            case 2 % per channel exponential smoothing
                % --- EWMA-based per-channel badness (recommended) ---
                % Parameters (put in ble struct or tune here)
                if ~isfield(ble,'ewma_alpha'), ble.ewma_alpha = 0.2; end
                if ~isfield(ble,'ewma_bad_threshold'), ble.ewma_bad_threshold = 0.5; end
                if ~isfield(ble,'ewma_recovery_streak'), ble.ewma_recovery_streak = 5; end
                if ~isfield(ble,'min_channels'), ble.min_channels = 20; end

                % Initialize EWMA arrays if needed
                if ~isfield(chan,'badnessEWMA') || isempty(chan.badnessEWMA)
                    chan.badnessEWMA = zeros(1, ble.Ndata);
                end
                if ~isfield(chan,'goodStreak') || isempty(chan.goodStreak)
                    chan.goodStreak = zeros(1, ble.Ndata);
                end

                % Update: for each channel, compute observed fail fraction since last eval
                for cidx = 1:ble.Ndata
                    a = chan.attempts(cidx);
                    f = chan.failures(cidx);
                    if a > 0
                        obs = f / a;    % observed fraction (0..1)
                        % Update EWMA
                        chan.badnessEWMA(cidx) = ...
                            (1-ble.ewma_alpha)*chan.badnessEWMA(cidx) + ble.ewma_alpha*obs;
                        % reset counters (we consumed these observations)
                        chan.attempts(cidx) = 0;
                        chan.failures(cidx) = 0;
                    else
                        obs = 0;
                    end

                    % Mark/unmark logic with streak-based recovery
                    if chan.badnessEWMA(cidx) > ble.ewma_bad_threshold && ~chan.isBad(cidx)
                        chan.isBad(cidx) = true;
                        chan.lastBadTime_ms(cidx) = simClock_ms;
                        fprintf('EWMA: Mark channel %d BAD at t=%.1f ms (ewma=%.2f)\n', cidx-1, simClock_ms, chan.badnessEWMA(cidx));
                    end

                    if chan.isBad(cidx)
                        % require consecutive good observations to re-enable (hysteresis)
                        if obs < 0.2 % treat this eval as 'good'
                            chan.goodStreak(cidx) = chan.goodStreak(cidx) + 1;
                        else
                            chan.goodStreak(cidx) = 0;
                        end
                        if chan.goodStreak(cidx) >= ble.ewma_recovery_streak ...
                                && (simClock_ms - chan.lastBadTime_ms(cidx)) > ble.recovery_time_ms
                            chan.isBad(cidx) = false;
                            chan.badnessEWMA(cidx) = chan.badnessEWMA(cidx) * 0.5; % accelerate recovery
                            chan.goodStreak(cidx) = 0;
                            fprintf('EWMA: Recovering channel %d at t=%.1f ms\n', cidx-1, simClock_ms);
                        end
                    end
                end

                % Ensure minimum number of good channels
                if sum(~chan.isBad) < ble.min_channels
                    % re-enable best channels by EWMA (lowest badness)
                    [~, idx] = sort(chan.badnessEWMA,'ascend');
                    needed = ble.min_channels - sum(~chan.isBad);
                    for ii = 1:needed
                        chan.isBad(idx(ii)) = false;
                    end
                    fprintf('EWMA: Enforced min channels -> enabled %d best channels\n', needed);
                end

            case 3 % energy / RSSI based classification
                % --- Params (defaults if not provided) ---
                if ~isfield(ble,'energy_threshold_dBm'), ble.energy_threshold_dBm = -60; end
                if ~isfield(ble,'energy_history_len'), ble.energy_history_len = 8; end
                if ~isfield(ble,'energy_recovery_count'), ble.energy_recovery_count = 3; end
                if ~isfield(ble,'min_channels_for_use'), ble.min_channels_for_use = 20; end
                if ~isfield(ble,'energy_hysteresis_dB'), ble.energy_hysteresis_dB = 6; end

                % Loop channels and decide based on median of recent energy samples
                for cidx = 1:ble.Ndata
                    samples = chan.energy_history{cidx};
                    if isempty(samples)
                        med = -Inf;
                    else
                        % use recent window (end of array)
                        n = min(numel(samples), ble.energy_history_len);
                        med = median(samples(end-n+1:end));
                    end

                    % Mark bad if median energy (noise+interf) above threshold
                    if med > ble.energy_threshold_dBm && ~chan.isBad(cidx)
                        chan.isBad(cidx) = true;
                        chan.lastBadTime_ms(cidx) = simClock_ms;
                        chan.energy_bad_count(cidx) = 0;
                        fprintf('ENERGY: Mark channel %d BAD at t=%.1f ms (med_dBm=%.1f)\n', cidx-1, simClock_ms, med);
                    end

                    % Recovery: require consecutive low-energy medians + min time
                    if chan.isBad(cidx)
                        if med <= (ble.energy_threshold_dBm - ble.energy_hysteresis_dB)
                            chan.energy_bad_count(cidx) = chan.energy_bad_count(cidx) + 1;
                        else
                            chan.energy_bad_count(cidx) = 0;
                        end
                        if chan.energy_bad_count(cidx) >= ble.energy_recovery_count ...
                                && (simClock_ms - chan.lastBadTime_ms(cidx)) > ble.recovery_time_ms
                            chan.isBad(cidx) = false;
                            chan.energy_bad_count(cidx) = 0;
                            % optionally reset attempts/failures
                            chan.attempts(cidx) = 0;
                            chan.failures(cidx) = 0;
                            fprintf('ENERGY: Recovering channel %d at t=%.1f ms\n', cidx-1, simClock_ms);
                        end
                    end
                end

                % Ensure minimum number of good channels: re-enable lowest-energy channels if needed
                if sum(~chan.isBad) < ble.min_channels_for_use
                    energies = zeros(1, ble.Ndata);
                    for cidx = 1:ble.Ndata
                        s = chan.energy_history{cidx};
                        if isempty(s)
                            energies(cidx) = Inf;
                        else
                            energies(cidx) = median(s(max(1,end-ble.energy_history_len+1):end));
                        end
                    end
                    [~, idx] = sort(energies,'ascend'); % prefer lowest energy channels
                    need = ble.min_channels_for_use - sum(~chan.isBad);
                    ii = 1; re = 0;
                    while re < need && ii <= ble.Ndata
                        c = idx(ii);
                        if chan.isBad(c)
                            chan.isBad(c) = false;
                            fprintf('ENERGY: Forcing channel %d GOOD to meet min_channels at t=%.1f ms\n', c-1, simClock_ms);
                            re = re + 1;
                        end
                        ii = ii + 1;
                    end
                end

            case 4 % combined: EWMA failure fraction + normalized energy score
                % Gate evaluation so there's enough data (optional but recommended)
                if ~isfield(ble,'chan_quality_window'), ble.chan_quality_window = 50; end
                if mod(sum(chan.attempts), ble.chan_quality_window) ~= 0
                    break; % wait until we've collected enough attempts
                end

                % --- Params and defaults ---
                if ~isfield(ble,'comb_alpha'), ble.comb_alpha = 0.25; end
                if ~isfield(ble,'comb_bad_threshold'), ble.comb_bad_threshold = 0.45; end
                if ~isfield(ble,'energy_weight'), ble.energy_weight = 0.5; end
                if ~isfield(ble,'min_channels_for_use'), ble.min_channels_for_use = 20; end
                if ~isfield(ble,'energy_norm_lo'), ble.energy_norm_lo = -90; end
                if ~isfield(ble,'energy_norm_hi'), ble.energy_norm_hi = -20; end
                if ~isfield(ble,'energy_history_len'), ble.energy_history_len = 8; end

                if ~isfield(chan,'comb_score') || isempty(chan.comb_score)
                    chan.comb_score = zeros(1,ble.Ndata);
                end

                % For diagnostics: track how many channels exceed the threshold
                nAbove = 0;

                % Compute observed metric for each channel and update EWMA
                for cidx = 1:ble.Ndata
                    a = chan.attempts(cidx);
                    f = chan.failures(cidx);

                    % fraction of failures over attempts (safe divide)
                    frac = f / max(1, a);  % 0..1

                    % energy normalized 0..1 (use median of recent samples if present)
                    s = {};
                    if isfield(chan,'energy_history')
                        s = chan.energy_history{cidx};
                    end
                    if isempty(s)
                        % fallback: if we have no energy history assume neutral energy (0.5)
                        eNorm = 0.5;
                    else
                        n = min(length(s), ble.energy_history_len);
                        med = median(s(end-n+1:end));
                        eNorm = (med - ble.energy_norm_lo) / (ble.energy_norm_hi - ble.energy_norm_lo);
                        eNorm = min(max(eNorm,0),1);
                    end

                    % observed combined metric (0..1)
                    observed = (1-ble.energy_weight)*frac + ble.energy_weight*eNorm;

                    % EWMA update of comb_score
                    chan.comb_score(cidx) = (1-ble.comb_alpha)*chan.comb_score(cidx) + ble.comb_alpha*observed;

                    % Only reset the per-channel short-term counters if they were used
                    if a > 0
                        chan.attempts(cidx) = 0;
                        chan.failures(cidx) = 0;
                    end

                    % Decision: mark bad if EWMA exceeds threshold
                    if chan.comb_score(cidx) > ble.comb_bad_threshold && ~chan.isBad(cidx)
                        chan.isBad(cidx) = true;
                        chan.lastBadTime_ms(cidx) = simClock_ms;
                        fprintf('COMB: Mark ch %d BAD at t=%.1f ms (score=%.3f)\n', cidx-1, simClock_ms, chan.comb_score(cidx));
                    end

                    % Recovery: require time + score drop below a fraction
                    if chan.isBad(cidx) && (simClock_ms - chan.lastBadTime_ms(cidx)) > ble.recovery_time_ms
                        if chan.comb_score(cidx) < (ble.comb_bad_threshold * 0.6)
                            chan.isBad(cidx) = false;
                            chan.comb_score(cidx) = chan.comb_score(cidx) * 0.5;
                            fprintf('COMB: Recovering ch %d at t=%.1f ms\n', cidx-1, simClock_ms);
                        end
                    end

                    if chan.comb_score(cidx) > ble.comb_bad_threshold
                        nAbove = nAbove + 1;
                    end
                end

                % Debug: show how many channels were above threshold (uncomment to see)
                % fprintf('DBG: %d channels above comb threshold (%.2f)\n', nAbove, ble.comb_bad_threshold);

                % Optional host override if provided (host bitmask in ble.host_channel_map)
                if isfield(ble,'host_channel_map') && ~isempty(ble.host_channel_map)
                    mask = ble.host_channel_map; % logical vector length Ndata, true=usable
                    chan.isBad(~mask) = true;
                end

                % enforce minimum channels
                if sum(~chan.isBad) < ble.min_channels_for_use
                    [~, idx] = sort(chan.comb_score, 'ascend'); % lowest score = best
                    need = ble.min_channels_for_use - sum(~chan.isBad);
                    ii = 1; re = 0;
                    while re < need && ii <= ble.Ndata
                        c = idx(ii);
                        if chan.isBad(c)
                            chan.isBad(c) = false;
                            fprintf('COMB: Forcing channel %d GOOD to meet min_channels at t=%.1f ms\n', c-1, simClock_ms);
                            re = re + 1;
                        end
                        ii = ii + 1;
                    end
                end


            case 5
                
            otherwise
                
        end
    end % attempts

    % record per-packet stats
    results.packetSent = results.packetSent + 1;
    results.retransmissions(pktIdx) = attempts - 1;
    results.totalRetransmissions = results.totalRetransmissions + (attempts - 1);
    if success
        latency_ms = simClock_ms - startTime_ms;
        results.latencies_ms(end+1) = latency_ms;
    else
        simClock_ms = simClock_ms + sim.connInterval_ms;
    end

    if mod(pktIdx, 200) == 0
        fprintf('Packet %d/%d, success %d, time %.1f s\n', pktIdx, sim.totalPackets, results.packetSuccess, simClock_ms/1000);
    end
end % packets

% trim timeline arrays
chanStateTimeline = chanStateTimeline(:, 1:eventIdx);
eventChannel = eventChannel(1:eventIdx);
eventSuccess = eventSuccess(1:eventIdx);
eventTime_ms = eventTime_ms(1:eventIdx);

simTotalTime_ms = simClock_ms;

%% Metrics
totalSent = results.packetSent;
totalSuccess = results.packetSuccess;
packetLossRate = 1 - totalSuccess/totalSent;
totalPayloadBits = totalSuccess * sim.payloadBytes * 8;
throughput_bps = totalPayloadBits / (simTotalTime_ms/1000);
p95_latency = prctile(results.latencies_ms, 95);
p99_latency = prctile(results.latencies_ms, 99);
max_latency = max(results.latencies_ms);

fprintf('\n--- Summary ---\n');
fprintf('AFH selection algorithm: %d, classification algorithm: %d\n', ble.afh_selection_algorithm, ble.afh_classification_algorithm);
fprintf('Packets: %d, Success: %d, Lost: %d (loss=%.3f), Retransmissions total: %d, Retransmissions/packet: %.3f\n', ...
        totalSent, totalSuccess, totalSent-totalSuccess, packetLossRate, results.totalRetransmissions, results.totalRetransmissions/totalSent);
fprintf('Throughput: %.1f bps\n', throughput_bps);
fprintf('Median latency: %.2f ms, p95: %.2f ms, p99: %.2f ms, max: %.2f ms\n', median(results.latencies_ms), p95_latency, p99_latency, max_latency);


%% Plots
% 1) Channels vs time heatmap with success/failure overlay
figure('Name','Channels vs Event','NumberTitle','off','Position',[100 100 1100 500],'WindowStyle','docked');
imagesc(1:eventIdx, 0:ble.Ndata-1, 1-chanStateTimeline);
colormap(flipud(gray)); % good = white, bad = black-ish
xlabel('Event index'); ylabel('BLE data channel (0..36)');
title('Channel allowed (white) vs excluded (black) over events');
colorbar; caxis([0 1]);

hold on;
% overlay successes (green dot) and failures (red x) at their event/channel
succIdx = find(eventSuccess);
failIdx = find(~eventSuccess);
scatter(succIdx, eventChannel(succIdx)-1, 12, 'g', 'filled');
scatter(failIdx, eventChannel(failIdx)-1, 20, 'r', 'x');
legend({'success','failure'}, 'Location','northoutside', 'Orientation','horizontal');
hold off;

% 2) Retransmissions per packet, integer-centered bars, log y-scale
figure('Name','Retransmissions per Packet','NumberTitle','off','Position',[150 150 600 400],'WindowStyle','docked');
maxR = sim.maxRetransmit;
counts = histcounts(results.retransmissions(1:totalSent), -0.5:1:(maxR+0.5)); % bin edges centered on integers
bar(0:maxR, counts, 'BarWidth', 0.7);
set(gca,'YScale','log');
xlabel('Retransmissions'); ylabel('Count (log scale)');
title('Retransmissions per packet (log y-axis)');
grid on;

% 3) Latency CDF
figure('Name','Latency CDF','NumberTitle','off','WindowStyle','docked');
histogram(results.latencies_ms, 100, 'Normalization','cdf');
xlabel('Latency (ms)'); ylabel('CDF'); title('Latency CDF'); grid on;

% 4) Latency vs Percentile (log y-scale to show tail spikes)
figure('Name','Latency vs Percentile','NumberTitle','off','WindowStyle','docked');
pct = linspace(50, 100, 500); % show from median to 100th percentile (tail focus)
latVals = prctile(results.latencies_ms, pct);
% plot percentile (x) vs latency (y) on log scale for y
semilogy(pct, latVals, '-','LineWidth',1.5);
xlabel('Percentile (%)'); ylabel('Latency (ms) - log scale');
title('Latency vs Percentile (tail emphasis)');
grid on;


end % main function

%% ----------------- Nested helper functions -----------------
    % ----------------- Channel selection dispatcher (explicit args) -----------------
    function ch = select_channel_AFH(counter, last_ch, ble_in, chan_in)
        % Dispatcher for AFH selection algorithms with explicit variable passing
        switch ble_in.afh_selection_algorithm
            case 1
                ch = select_channel_alg1(counter, ble_in, chan_in);
            case 2
                ch = select_channel_alg2(counter, last_ch, ble_in, chan_in);
            case 3
                ch = custom_selector(counter, last_ch, ble_in, chan_in);
            otherwise
                ch = select_channel_alg1(counter, ble_in, chan_in);
        end
    end

    function goodList = getGoodChannels(ble_in, chan_in)
        % return allowed channels (1-based indices)
        goodList = find(~chan_in.isBad);
    end

    function ch = select_channel_alg1(counter, ble_in, chan_in)
        % Simple remap: remap over allowed list
        goodList = getGoodChannels(ble_in, chan_in);
        N = numel(goodList);
        if N == 0
            ch = mod(counter, ble_in.Ndata) + 1;
            return;
        end
        idx = mod(counter * ble_in.hopIncrement, N) + 1;
        ch = goodList(idx);
    end

    function ch = select_channel_alg2(counter, last_ch, ble_in, chan_in)
        goodList = getGoodChannels(ble_in, chan_in);
        N = numel(goodList);
        ble_in.channelIdentifier = bitxor(uint16(bitshift(ble_in.accessAddress, -16)), uint16(bitand(ble_in.accessAddress, uint32(65535))));
        temp = bitxor(counter,ble_in.channelIdentifier);
        for i = 1:3
            % permutation
            tempb = int2bit(temp,16);
            tempbb = zeros(1,16);
            tempbb(1:8) = tempb(8:-1:1);
            tempbb(9:16) = tempb(16:-1:9);
            temp = bit2int(tempbb',16);
            % mam
            temp = uint16(mod(((17*uint32(temp))+uint32(ble_in.channelIdentifier)),2^16));
        end
        unmappedChannel = mod(bitxor(temp, ble_in.channelIdentifier),37);
        if N == 0
            ch = unmappedChannel+1;
            return;
        end
        remapIndex = mod(unmappedChannel,N)+1;
        ch = goodList(remapIndex);
    end



    function ch = custom_selector(counter, last_ch, ble_in, chan_in)
        % Example custom selector using weighted "health" scores
        failureRate = chan_in.failures ./ max(1, chan_in.attempts);
        scores = 1 - failureRate;
        scores(chan_in.isBad) = 0.1; % low but non-zero chance to retest
        scores = max(scores, 0.01);
        idx = randsample(1:ble_in.Ndata, 1, true, scores);
        ch = idx;
    end


        function currentInterfPower = getInterferencePowerForChannel(chIdx, time_ms, interferers, interfererActive, nextInterfererEnd_ms, interfererActiveReason)
        dbm2mW_local = @(d) 10.^((d-30)/10);
        currentInterfPower = 0;
        for ii = 1:numel(interferers)
            if interfererActive(ii) && time_ms < nextInterfererEnd_ms(ii)
                center = interferers(ii).centerCh + 1; % convert 0-based to 1-based if needed
                bw = interferers(ii).bwCh;
                dist = abs(chIdx - center);
                if dist <= bw/2
                    weight = 1 - dist/(bw/2);

                    % Prefer mean_effective_dBm set by the scheduler, otherwise fall back to reason-specific means
                    if isfield(interferers(ii),'mean_effective_dBm') && ~isempty(interferers(ii).mean_effective_dBm)
                        eff_mean = interferers(ii).mean_effective_dBm;
                    else
                        % fallback: pick based on reason (if provided) or use base mean
                        eff_mean = interferers(ii).mean_base_dBm;
                        if exist('interfererActiveReason','var') && ~isempty(interfererActiveReason(ii))
                            r = interfererActiveReason(ii);
                            if r == "periodic" && isfield(interferers(ii),'mean_periodic_dBm')
                                eff_mean = interferers(ii).mean_periodic_dBm;
                            elseif r == "random" && isfield(interferers(ii),'mean_random_dBm')
                                eff_mean = interferers(ii).mean_random_dBm;
                            elseif r == "mixed" && isfield(interferers(ii),'mean_mixed_dBm')
                                eff_mean = interferers(ii).mean_mixed_dBm;
                            end
                        end
                    end

                    p = dbm2mW_local(eff_mean) * weight;
                    currentInterfPower = currentInterfPower + p;
                end
            end
        end
    end
