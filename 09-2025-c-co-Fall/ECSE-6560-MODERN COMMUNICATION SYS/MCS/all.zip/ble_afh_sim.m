function ble_afh_sim()
% ble_afh_sim() - BLE AFH simulator (predictive algorithms removed)
% run ble_afh_sim()

%% Simulation Parameters
rng(0); clearvars -except rng selAlg classAlg; close all;

if ~exist('selAlg', 'var')
    selAlg = 1;
end
if ~exist('classAlg', 'var')
    classAlg = 4; % valid: 0..4
end

sim.totalPackets = 20000;
sim.payloadBytes = 20;
sim.maxRetransmit = 24;
sim.connInterval_ms = 7.5;
sim.phy_rate = 1e6;
sim.sampleRate = 1e6;
sim.bt_gaussianBT = 0.5;
sim.modIndex = 0.5;
sim.preambleBits = 8*1;
sim.accessAddrBits = 32;
sim.crcBits = 24;
sim.psdu_len_bytes = sim.payloadBytes;

%% Noise & Interference Parameters
chan.noise_dBm = -90;
chan.signal_power_dBm = -40;
chan.interference_power_dBm = -40;
chan.awgn_enable = true;
chan.interference_enable = true;

%% Interferers
interferers = struct(...
    'centerCh', { 5,18,30,12,7,25,2,32,20,14,9,28,16,4,22,11,33,0,35,19 }, ...
    'bwCh',     { 20,20,20,3,2,4,1,3,2,2,1,3,2,1,3,1,2,1,1,2 }, ...
    'mean_dBm', { -5,-8,-6,0,-10,-15,-20,-18,-12,-15,-5,-20,-28,-28,-16,-22,-10,-35,-20,-13 }, ...
    'onProb',   { 0.95,0.9,0.9,0.25,0.12,0.35,0.05,0.2,0.4,0.18,0.07,0.22,0.15,0.06,0.3,0.1,0.6,0.02,0.08,0.25 }, ...
    'duration_mean_ms', { 2000,1500,1800,80,40,300,15,120,200,60,20,100,50,10,250,30,400,8,70,90 }, ...
    'isPeriodic', num2cell(false(1,20)), ...
    'burst_on_ms', num2cell(zeros(1,20)), ...
    'burst_interval_ms', num2cell(zeros(1,20)) ...
);

for k = 1:numel(interferers)
    interferers(k).mean_dBm = interferers(k).mean_dBm + chan.interference_power_dBm;
end

%% BLE / AFH parameters
ble.Ndata = 37;
ble.hopIncrement = 67;
ble.channel_map = true(1, ble.Ndata);
ble.chan_quality_window = 50;
ble.bad_rate_threshold = 0.4;
ble.min_channels_for_use = 20;
ble.recovery_time_ms = 2000;

ble.afh_selection_algorithm = selAlg;      % 1..3
ble.afh_classification_algorithm = classAlg; % 0..4 ONLY

ble.accessAddress = uint32(hex2dec('8E89BED6'));
ble.channelIdentifier = uint16(0);
ble.eventCounter = 0;

%% Derived
bitsPerPacket = sim.preambleBits + sim.accessAddrBits + 8*sim.psdu_len_bytes + sim.crcBits;
dbm2mW = @(d) 10.^((d-30)/10);
signal_power_mW = dbm2mW(chan.signal_power_dBm);
noise_floor_mW = dbm2mW(chan.noise_dBm);

%% Channel state
chan.attempts = zeros(1, ble.Ndata);
chan.failures = zeros(1, ble.Ndata);
chan.lastBadTime_ms = -inf(1, ble.Ndata);
chan.isBad = ~ble.channel_map;
chan.energy_history = cell(1, ble.Ndata);
chan.energy_bad_count = zeros(1, ble.Ndata);

%% Results
results.packetSent = 0;
results.packetSuccess = 0;
results.latencies_ms = [];
results.retransmissions = zeros(sim.totalPackets,1);
results.totalRetransmissions = 0;

%% Main loop
simClock_ms = 0;
lastUsedChannel = 1;
hopCounter = 0;

disconnections = 0;

for pktIdx = 1:sim.totalPackets
    attempts = 0; success = false;
    startTime_ms = simClock_ms;

    while ~success
        attempts = attempts + 1;
        hopCounter = hopCounter + 1;
        if mod(attempts,sim.maxRetransmit)==0
            disconnections = disconnections + 1;
        end

        ch = select_channel_AFH(hopCounter, lastUsedChannel, ble, chan);
        lastUsedChannel = ch;
        chan.attempts(ch) = chan.attempts(ch) + 1;

        interfPower_mW = getInterferencePowerForChannel(ch, simClock_ms, interferers);
        totalNoise_mW = noise_floor_mW + interfPower_mW;

        SNR_linear = signal_power_mW / max(1e-12, totalNoise_mW);
        EbN0 = SNR_linear * (sim.sampleRate / sim.phy_rate);
        ber = min(max(0.5 * erfc( sqrt(EbN0/2) ),1e-12),0.5);
        pktLenBits = bitsPerPacket;
        pErr = 1 - (1 - ber)^pktLenBits;

        if rand > pErr
            success = true;
            results.packetSuccess = results.packetSuccess + 1;
        else
            chan.failures(ch) = chan.failures(ch) + 1;
            chan.lastBadTime_ms(ch) = simClock_ms;
        end

        %% AFH classification (0..4 only)
        switch ble.afh_classification_algorithm
            case 0
                % baseline
            case 1
                if mod(sum(chan.attempts), ble.chan_quality_window) == 0
                    fr = chan.failures ./ max(1, chan.attempts);
                    for c = 1:ble.Ndata
                        if fr(c) > ble.bad_rate_threshold
                            chan.isBad(c) = true;
                            chan.lastBadTime_ms(c) = simClock_ms;
                        end
                        if chan.isBad(c) && (simClock_ms - chan.lastBadTime_ms(c)) > ble.recovery_time_ms
                            chan.isBad(c) = false;
                            chan.attempts(c) = 0; chan.failures(c) = 0;
                        end
                    end
                end
            case 2
                if ~isfield(chan,'badnessEWMA')
                    chan.badnessEWMA = zeros(1, ble.Ndata);
                end
                alpha = 0.2; thr = 0.5;
                for c = 1:ble.Ndata
                    if chan.attempts(c) > 0
                        obs = chan.failures(c)/chan.attempts(c);
                        chan.badnessEWMA(c) = (1-alpha)*chan.badnessEWMA(c)+alpha*obs;
                        chan.attempts(c)=0; chan.failures(c)=0;
                    end
                    if chan.badnessEWMA(c) > thr
                        chan.isBad(c)=true;
                    end
                end
            case 3
                thr = -60; win = 8;
                for c = 1:ble.Ndata
                    s = chan.energy_history{c};
                    if ~isempty(s)
                        med = median(s(max(1,end-win+1):end));
                        if med > thr
                            chan.isBad(c)=true;
                        end
                    end
                end
            case 4
                alpha = 0.25; thr = 0.45;
                if ~isfield(chan,'comb_score')
                    chan.comb_score = zeros(1, ble.Ndata);
                end
                for c = 1:ble.Ndata
                    frac = chan.failures(c)/max(1,chan.attempts(c));
                    chan.comb_score(c) = (1-alpha)*chan.comb_score(c)+alpha*frac;
                    if chan.comb_score(c) > thr
                        chan.isBad(c)=true;
                    end
                    chan.attempts(c)=0; chan.failures(c)=0;
                end
        end

        simClock_ms = simClock_ms + sim.connInterval_ms;
    end

    results.packetSent = results.packetSent + 1;
    results.retransmissions(pktIdx) = attempts - 1;
    results.totalRetransmissions = results.totalRetransmissions + (attempts - 1);
    results.latencies_ms(end+1) = simClock_ms - startTime_ms;
end

%% Metrics & Summary
simTotalTime_ms = simClock_ms;

totalSent = results.packetSent;
totalSuccess = results.packetSuccess;
packetLossRate = 1 - totalSuccess/totalSent;
totalPayloadBits = totalSuccess * sim.payloadBytes * 8;
throughput_bps = totalPayloadBits / (simTotalTime_ms/1000);
p95_latency = prctile(results.latencies_ms, 95);
p99_latency = prctile(results.latencies_ms, 99);
max_latency = max(results.latencies_ms);

selNames = containers.Map({1,2,3},{'1 simple','2 pseudo-random','3 custom'});
classNames = containers.Map(0:4,{...
    '0 none (baseline)',...
    '1 fixed-window failure-rate',...
    '2 EWMA failure fraction',...
    '3 energy (RSSI/ED)',...
    '4 combined'});

selName = 'unknown'; className = 'unknown';
if isKey(selNames,ble.afh_selection_algorithm), selName = selNames(ble.afh_selection_algorithm); end
if isKey(classNames,ble.afh_classification_algorithm), className = classNames(ble.afh_classification_algorithm); end

fprintf('\n--- Summary ---\n');
fprintf('AFH selection: %s\n', selName);
fprintf('AFH classification: %s\n', className);
fprintf('Packets: %d, Success: %d, Loss rate: %.3f, Retransmissions: %d, Disconnections: %d\n',...
    totalSent,totalSuccess,packetLossRate,results.totalRetransmissions,disconnections);
fprintf('Throughput: %.1f bps\n', throughput_bps);
fprintf('Median latency: %.2f ms, p95: %.2f ms, p99: %.2f ms, max: %.2f ms\n',...
    median(results.latencies_ms),p95_latency,p99_latency,max_latency);

%% Plots
figure('Name','Retransmissions per Packet','NumberTitle','off','WindowStyle','docked');
counts = histcounts(results.retransmissions(1:totalSent),-0.5:1:(sim.maxRetransmit+0.5));
bar(0:sim.maxRetransmit,counts,'BarWidth',0.7);
set(gca,'YScale','log'); grid on;
xlabel('Retransmissions'); ylabel('Count (log)'); title('Retransmissions per Packet');

figure('Name','Latency CDF','NumberTitle','off','WindowStyle','docked');
histogram(results.latencies_ms,100,'Normalization','cdf'); grid on;
xlabel('Latency (ms)'); ylabel('CDF'); title('Latency CDF');
end

%% -------- Helper functions --------
function ch = select_channel_AFH(counter, last_ch, ble, chan)
    switch ble.afh_selection_algorithm
        case 1
            ch = select_channel_alg1(counter, ble, chan);
        case 2
            ch = select_channel_alg2(counter, last_ch, ble, chan);
        otherwise
            ch = select_channel_alg1(counter, ble, chan);
    end
end

function good = getGoodChannels(chan)
    good = find(~chan.isBad);
end

function ch = select_channel_alg1(counter, ble, chan)
    g = getGoodChannels(chan);
    if isempty(g)
        ch = mod(counter, ble.Ndata)+1; return;
    end
    ch = g(mod(counter*ble.hopIncrement,numel(g))+1);
end

function ch = select_channel_alg2(counter, last_ch, ble, chan)
    g = getGoodChannels(chan);
    if isempty(g)
        ch = mod(counter, ble.Ndata)+1; return;
    end
    ch = g(mod(counter,numel(g))+1);
end

function p = getInterferencePowerForChannel(ch, time_ms, interferers)
    dbm2mW = @(d) 10.^((d-30)/10);
    p = 0;
    for ii = 1:numel(interferers)
        if rand < interferers(ii).onProb
            center = interferers(ii).centerCh + 1;
            bw = interferers(ii).bwCh;
            dist = abs(ch-center);
            if dist <= bw/2
                w = 1 - dist/(bw/2);
                p = p + dbm2mW(interferers(ii).mean_dBm)*w;
            end
        end
    end
end
